# ARCHIVED — Projet Hermes — définition de départ

Le contenu de ce document a été archivé et vidé : voir `archive/docs_human/README.md` pour la version complète historique.
