# ARCHIVED — Plan de développement Projet Hermes

Le contenu de ce document a été archivé et vidé : voir `archive/docs_human/README.md` pour la version complète historique.

## Analyse des instructions Copilot

### Principes architecturaux
- **SOC** (Separation of Concerns): Architecture en couches distinctes
- **LOD** (Law of Demeter): Limiter les dépendances transitives
- **KIS** (Keep It Simple): Solutions minimales viables
- **DRY** (Don't Repeat Yourself): Factorisation systématique
- **Autonomie IA opérable**: Workflows automatisables

### Stack technique cible
- **Frontend**: Next.js 14 (App Router) + React + TypeScript + Zustand + Tailwind CSS
- **Canvas**: Paper.js (vectoriel), WebGL/PixiJS (raster)
- **Backend**: NestJS + TypeScript + REST + GraphQL + WebSocket
- **Persistance**: PostgreSQL + Redis + Meilisearch
- **Jobs**: BullMQ sur Redis
- **Monorepo**: pnpm workspaces

### Fonctionnalités P0 (priorité maximale)
1. Éditeur vectoriel MVP (Canvas 2D, calques, formes, export SVG/PNG)
2. Éditeur raster basique (calques, ajustements, filtres WebGL)
3. Workflows export manuel (templates réseaux sociaux, guides impression)

## Plan d'implémentation

### Étape 1: Structure monorepo
- [x] Analyser structure existante
- [ ] Créer `apps/web/` (Next.js 14)
- [ ] Créer `apps/api/` (NestJS)
- [ ] Créer `packages/ui/` (composants partagés)
- [ ] Créer `packages/canvas/` (moteurs Paper.js, WebGL)
- [ ] Créer `packages/types/` (types TypeScript partagés)

### Étape 2: Configuration environnement
- [ ] Docker Compose (PostgreSQL, Redis, Meilisearch)
- [ ] Scripts bootstrap/start-session
- [ ] Configuration ESLint + Prettier monorepo
- [ ] Configuration Vitest
- [ ] Configuration Playwright E2E

### Étape 3: Backend (apps/api)
- [ ] Architecture NestJS modulaire
  - Module auth (JWT)
  - Module projects
  - Module canvas-vector
  - Module canvas-raster
  - Module export
- [ ] Couches architecture
  - Interfaces (controllers, DTOs)
  - Application (use cases, orchestration)
  - Domain (entités, logique métier)
  - Infrastructure (repos, adaptateurs)
- [ ] WebSocket pour collaboration temps réel
- [ ] Jobs BullMQ (exports asynchrones)

### Étape 4: Frontend (apps/web)
- [ ] Structure Next.js 14 App Router
  - Layout principal
  - Page d'accueil
  - Page éditeur vectoriel
  - Page éditeur raster
  - Page exports/templates
- [ ] Design system Tailwind + composants UI
- [ ] Zustand (state management)
- [ ] TanStack Query (cache API)
- [ ] Canvas vectoriel (Paper.js)
  - Formes de base
  - Calques
  - Transformations
  - Export SVG/PNG
- [ ] Canvas raster (WebGL/PixiJS)
  - Calques
  - Filtres
  - Ajustements
  - Export PNG

### Étape 5: Packages partagés
- [ ] `packages/ui`: Storybook + composants
- [ ] `packages/canvas`: Abstractions moteurs canvas
- [ ] `packages/types`: Types partagés
- [ ] `packages/shared`: Utilitaires (déjà en place)

### Étape 6: Tests & qualité
- [ ] Tests unitaires Vitest (>80% couverture)
- [ ] Tests E2E Playwright (parcours critiques)
- [ ] Intégration CI GitHub Actions
- [ ] Sécurité: Trivy + npm audit

### Étape 7: Documentation
- [ ] README principal avec getting started
- [ ] ADR (Architecture Decision Records)
- [ ] Documentation API (Swagger)
- [ ] Documentation composants (Storybook)
- [ ] Guide contributeur

## Ordre d'exécution immédiat

1. **Structure monorepo** (apps/web, apps/api, packages)
2. **Docker Compose** (services backend)
3. **Backend minimal** (NestJS + API santé)
4. **Frontend minimal** (Next.js + page accueil)
5. **Éditeur vectoriel MVP** (Paper.js + formes de base)
6. **Export SVG/PNG** (service backend + frontend)
7. **Tests & CI** (Vitest + Playwright + GitHub Actions)

## Conventions à respecter

### Structure fichiers
```
apps/
  web/
    src/
      app/              # Next.js 14 App Router
      components/       # Composants réutilisables
      lib/             # Utilitaires, config
      hooks/           # Custom hooks
      stores/          # Zustand stores
  api/
    src/
      interfaces/      # Controllers, DTOs, Guards
      application/     # Use cases, services
      domain/          # Entités, value objects, logic
      infrastructure/  # Repositories, adapters
      config/          # Configuration modules
packages/
  ui/                  # Design system
  canvas/              # Moteurs canvas
  types/               # Types partagés
  shared/              # Utilitaires (existant)
```

### Nomenclature
- Fichiers: kebab-case (`user-service.ts`)
- Classes: PascalCase (`UserService`)
- Fonctions/variables: camelCase (`getUserById`)
- Constantes: UPPER_SNAKE_CASE (`API_VERSION`)
- Interfaces: PascalCase avec I préfixe (`IUserRepository`)

### Tests
- Fichiers: `*.spec.ts` (unitaire), `*.e2e.ts` (E2E)
- Coverage minimal: 80%
- Tests rapides, isolés, déterministes

### Git
- Branches: `feature/`, `fix/`, `docs/`, `refactor/`
- Commits: Conventional Commits
- PR: template avec checklist

## Autoévaluation

### Points forts
- Plan exhaustif couvrant architecture, stack, conventions
- Respect strict des principes SOC, LOD, KIS, DRY
- Priorité claire sur fonctionnalités P0
- Structure modulaire évolutive

### Points faibles
- Plan ambitieux, nécessite phasage précis
- Risque de sur-ingénierie si toutes couches créées d'emblée
- Dépendances complexes entre packages

### Améliorations proposées
- Démarrer ultra-minimal (backend health check + frontend hello world)
- Ajouter fonctionnalités P0 itérativement
- Valider chaque étape avant passage suivante
- Documenter décisions architecturales en ADR

### Prochaine action
Créer la structure monorepo de base (apps/web, apps/api) avec configuration minimale.
