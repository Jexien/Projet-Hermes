# Implementation notes — mapping stories vers la stack allégée

Date : 2025-10-24

Ce document reprend les stories P0 et indique, pour chaque cas, des recommandations d'implémentation concrètes pour la phase initiale (local-first, stack allégée : React+TS, Vite, IndexedDB, react-konva, WebWorkers).

## P0-compte-utilisateur-basique

## P0-editeur-raster-mvp

## P0-editeur-raster-wireframes

## P0-editeur-vectoriel-mvp

## P0-editeur-vectoriel-wireframes

## P0-export-manuel-checklist / P0-export-manuel-stories

## Cross-cutting recommendations

## Priorités pour MVP
1. Implémenter le modèle document et l'export/import `.hermes.zip`.
2. Prototype UI minimal vectoriel (react-konva) + raster simple (Canvas) pour valider UX.
3. Ajouter IndexedDB persistence et autosave.
# ARCHIVED — Implementation notes — mapping stories vers la stack allégée

Le contenu de ce document a été archivé et vidé : voir `archive/docs_human/README.md` pour la version complète historique.
