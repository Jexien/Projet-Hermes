# Architecture Hermes (overview)

Voir `docs/overview.md` pour la synthèse et la navigation. Ce fichier conserve les conventions détaillées du monorepo et les recommandations d'organisation.

Structure recommandée:
- `packages/agents/` : runners d'agents
- `packages/shared/` : schémas et utilitaires (indexer, validate)
- `packages/core/` : composants réutilisables (approval engine, policies)
- `artifacts/` : zone d'échange append-only
# ARCHIVED — Architecture Hermes (overview)

Le contenu de ce document a été archivé et vidé : voir `archive/docs_human/README.md` pour la version complète historique.
