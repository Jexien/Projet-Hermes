---
Title: Simplification initiale de la stack (local-first, minimal)
Date: 2025-10-24
Status: accepted
Authors: équipe Hermes
---

Contexte
--------
Le dépôt initial proposait une pile ambitieuse (Next.js, NestJS, Postgres, Redis, Meilisearch, BullMQ, WebGL/WASM, etc.). Pour un PoC local-first et une adoption rapide par des testeurs non techniques, cette complexité est trop lourde.

Décision
--------
Nous adoptons une stratégie progressive : commencer par une stack locale et légère, puis évoluer en fonction des besoins.

Décision détaillée
- Frontend : TypeScript + React + Vite
- State : Zustand
- Rendu : react-konva (konva) + WebWorkers pour les traitements lourds
- Persistance initiale : IndexedDB (Dexie) + export/import zip
- Backend : aucun backend obligatoire au démarrage ; optionnellement Fastify + SQLite pour les contributeurs qui veulent un serveur local
- Tests/Qualité : Vitest, ESLint, Prettier

Raisons
-------
- Diminution de la barrière d'entrée pour les testeurs et contributeurs.
- Itération rapide sur l'UX et le format de document.
- Chemin d'évolution clair vers une architecture robuste si et quand nécessaire.

Conséquences
-----------
- Positives : déploiement simple, partage facile (GitHub Pages, fichiers ZIP), itérations rapides.
- Négatives : pas de collaboration temps réel intégrée, limitations de stockage côté client, certaines fonctions avancées (recherche, queue de jobs) nécessiteront des composants externes ultérieurement.

Alternatives considérées
-------------------------
1. Garder la stack complète immédiatement — rejetée à cause du coût d'installation et de maintenance pour le PoC.
2. Mode strictement no-install (index.html vanilla) — retenu comme option de prototype, mais nous choisissons React+TS pour la maintenabilité à moyen terme.

Plan de migration
-----------------
1. Implémenter prototype local-only.
2. Ajouter un serveur léger (Fastify+SQLite) si la demande multi-process apparaît.
3. Migrer vers Postgres/Redis/Meilisearch/BullMQ et NestJS si la charge et les exigences l'exigent.

Notes opérationnelles
---------------------
- Documenter les formats exportés et fournir des scripts d'import/export.
- Documenter la décision dans `docs/` et lier cette ADR aux tickets de migration.
